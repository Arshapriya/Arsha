require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const Razorpay = require('razorpay');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const cors = require('cors');

const app = express();
app.use(bodyParser.json());
app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));

const PORT = process.env.PORT || 4000;
const DATA_DIR = path.join(__dirname, 'data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const PRODUCTS_FILE = path.join(DATA_DIR, 'products.json');
const TX_FILE = path.join(DATA_DIR, 'txs.json');

function readJSON(file){ return JSON.parse(fs.readFileSync(file,'utf8') || 'null'); }
function writeJSON(file, obj){ fs.writeFileSync(file, JSON.stringify(obj, null, 2)); }
function getUsers(){ return readJSON(USERS_FILE); }
function getProducts(){ return readJSON(PRODUCTS_FILE); }
function saveProducts(p){ writeJSON(PRODUCTS_FILE, p); }
function getTx(){ return readJSON(TX_FILE); }
function saveTx(t){ writeJSON(TX_FILE, t); }

function getRazorpayForFarmer(farmerUsername){
  const users = getUsers();
  const farmer = users[farmerUsername] || {};
  const key_id = farmer.rzpKeyId || process.env.DEFAULT_RZP_KEY_ID;
  const key_secret = farmer.rzpKeySecret || process.env.DEFAULT_RZP_SECRET;
  if(!key_id || !key_secret){
    throw new Error('Razorpay keys missing for farmer and no default secret set on server.');
  }
  return new Razorpay({ key_id, key_secret });
}

app.get('/api/public', (req,res)=>{
  const products = getProducts();
  const users = getUsers();
  const farmers = Object.entries(users).filter(([k,v])=>v.role==='farmer')
    .map(([k,v])=>({ username:k, displayName:v.displayName }));
  res.json({ products, farmers });
});

app.post('/api/create_order', async (req,res)=>{
  try {
    const { productId, qty, buyerName, buyerContact } = req.body;
    const products = getProducts();
    const product = products.find(p=>p.id===productId);
    if(!product) return res.status(404).json({error:'Product not found'});
    if(product.qty < qty) return res.status(400).json({error:'Insufficient stock'});
    const amount = Math.round(product.price * qty) * 100;
    const farmerUsername = product.farmer;

    let razorpay = getRazorpayForFarmer(farmerUsername);
    const order = await razorpay.orders.create({
      amount, currency:"INR", receipt:"rcpt_"+Date.now(), payment_capture:1
    });

    const txs = getTx();
    const txObj = {
      localId: crypto.randomBytes(8).toString('hex'),
      razorpay_order_id: order.id,
      productId: product.id,
      productName: product.name,
      qty,
      total: amount/100,
      farmer: farmerUsername,
      buyerName,
      buyerContact,
      status: 'created',
      createdAt: new Date().toISOString()
    };
    txs.unshift(txObj);
    saveTx(txs);

    res.json({ orderId:order.id, amount:order.amount, currency:order.currency,
      key_id: razorpay.key_id || process.env.DEFAULT_RZP_KEY_ID,
      txLocalId: txObj.localId, product:{name:product.name}});
  } catch(err){ res.status(500).json({error:err.message}); }
});

app.post('/api/verify_payment',(req,res)=>{
  try {
    const { razorpay_payment_id, razorpay_order_id, razorpay_signature } = req.body;
    const txs = getTx();
    const txIndex = txs.findIndex(t=>t.razorpay_order_id===razorpay_order_id);
    if(txIndex===-1) return res.status(404).json({error:'Tx not found'});
    const txObj = txs[txIndex];
    const users = getUsers();
    const farmer = users[txObj.farmer];
    const key_secret = farmer.rzpKeySecret || process.env.DEFAULT_RZP_SECRET;
    const hmac = crypto.createHmac('sha256', key_secret);
    hmac.update(razorpay_order_id + "|" + razorpay_payment_id);
    const expected = hmac.digest('hex');
    if(expected !== razorpay_signature){
      txs[txIndex].status='signature_mismatch'; saveTx(txs);
      return res.status(400).json({verified:false,error:'Signature mismatch'});
    }
    txs[txIndex].status='paid'; txs[txIndex].paymentId=razorpay_payment_id; saveTx(txs);
    const products = getProducts();
    const product = products.find(p=>p.id===txObj.productId);
    if(product){ product.qty = Math.max(0, product.qty - txObj.qty); saveProducts(products); }
    res.json({verified:true, tx:txs[txIndex]});
  }catch(err){ res.status(500).json({error:err.message}); }
});

app.get('/api/txs',(req,res)=>res.json(getTx()));
app.get('/api/products',(req,res)=>res.json(getProducts()));
app.get('/api/users',(req,res)=>{
  const users=getUsers(); Object.values(users).forEach(u=>{ if(u.rzpKeySecret) delete u.rzpKeySecret; }); res.json(users);
});

app.listen(PORT,()=>console.log("Server running on port",PORT));
